#Nama : Ryan taufiq nurdiansyah fauji
#NIM : 210511048
#Kelas : R2
print(len("Ryan taufiq nurdiansyah fauji")) 
print(len((1,2,3,4,5,6,7,10)))
print(len(("210511048")))