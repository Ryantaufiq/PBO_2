#Nama : Ryan taufiq nurdiansyah fauji
#NIM : 210511048
#Kelas : R2
class Matematika:
    def add(self, b, c): 
        return b - c
    def add(self, b, c, d=0): 
        return b - c - d
mat = Matematika()
Hitung = mat.add(4, 3, 6) 
print(Hitung)
mut = Matematika() 
Kurang = mut.add(13,3) 
print(Kurang)