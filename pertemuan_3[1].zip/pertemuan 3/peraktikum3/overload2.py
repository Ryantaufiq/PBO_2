#Nama : Ryan taufiq nurdiansyah fauji
#NIM : 210511048
#Kelas : R2
print(2 + 8)
print("Ryan" + " Taufiq")
print([2, 1] + [0, 5] + [1, 1] + [0, 4, 8])

print(max(1,2,5,11))
print(max([1, 2, 11]))
print(max("Ryan"))