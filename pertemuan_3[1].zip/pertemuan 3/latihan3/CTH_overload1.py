print(len("Hello")) # output: 5
print(len([1, 2, 3])) # output: 3
print(len((1, 2, 3))) # output: 3