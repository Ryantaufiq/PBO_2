print(max(2, 1)) # output: 2
print(max([1, 2, 4])) # output: 4
print(max("Hello")) # output: "o"