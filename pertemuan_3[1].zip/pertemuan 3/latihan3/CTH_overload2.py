print(2 + 3) # output: 5
print("Hello" + " World") # output: Hello World
print([2, 1] + [4, 3]) # output: [2, 1, 4, 3]