a = [4, 6, 5]
a.sort()
print(a) # output: [4, 5, 6]
b = ["z", "x", "y"]
b.sort()
print(b) # output: ["x", "y", "z"]